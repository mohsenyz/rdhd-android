package com.rdhd.app.models

data class Service (
    val serviceName : String,
    val serviceIcon : Int
)