package com.rdhd.app.repositories.api;

public interface Api {



}
