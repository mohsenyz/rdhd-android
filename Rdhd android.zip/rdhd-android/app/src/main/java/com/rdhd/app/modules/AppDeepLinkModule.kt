package com.rdhd.app.modules

import com.airbnb.deeplinkdispatch.DeepLinkModule

@DeepLinkModule
class AppDeepLinkModule